

import React, { Component } from 'react';
import { AppRegistry, Text, View } from 'react-native';

export default class NewsDivs extends Component {
  render() {
      var s = this.props.textData.substring(0, 480);
      if(this.props.textData.length>480)
        s = s.concat("...");
      return (
            <View style={{flex:1, backgroundColor: '#000', margin: "3%", marginTop: "3%", marginBottom: "1.5%"}} >
                    <View style={{backgroundColor: '#fff', minHeight: "85%"}} >
                        <View style={{minHeight: "30%",backgroundColor: '#ccc7c5'}} />
                        <Text style={{padding: "5%", minHeight: "55%", color: "#000"}}>
                              {s}
                        </Text>
                    </View>
                    <View style={{minHeight: "15%", backgroundColor: '#ccc7c5'}} />
            </View>
      );
  }
}

