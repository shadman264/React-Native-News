/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View
} from 'react-native';
import NewsDiv from './NewsDiv';

export default class AwesomeProject extends Component {
  render() {
    return (
        <View style={{flex: 1}}>

            <NewsDiv textData="It works similarly to max-height in CSS, but in React Native you must use points or percentages. Ems and other unitsthis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textDatathis.props.textData are not supported.It works similarly to max-height in CSS, but in React Native you must use points or percentages. Ems and other units are not supported.It works similarly to max-height in CSS, but in React Native you must use points or percentages. Ems and other units are not supported."/>
            <NewsDiv textData="bokachoda"/>


        </View>

    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});

AppRegistry.registerComponent('AwesomeProject', () => AwesomeProject);
